from pydantic import BaseModel, Field
from typing import List, Optional
from enum import Enum
from uuid import uuid4

class Gender(str, Enum):
    male = 'male'
    female = 'female'
    other = 'other'

class ActivityLevel(str, Enum):
    sedentary = 'sedentary'
    light = 'light'
    moderate = 'moderate'
    active = 'active'
    very_active = 'very-active'

class UserProfile(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid4()))
    age: int
    gender: Gender
    weight_kg: float
    height_cm: float
    medical_conditions: Optional[List[str]] = []
    activity_level: ActivityLevel = ActivityLevel.sedentary
    exclusions: Optional[List[str]] = []

class ExerciseLog(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid4()))
    user_id: str
    date: str
    steps: Optional[int] = None
    minutes: Optional[int] = None
    intensity: Optional[str] = None

class MealItem(BaseModel):
    food: str
    portion: str

class Meal(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid4()))
    name: str
    time_of_day: str
    items: List[MealItem]

class DietPlan(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid4()))
    user_id: str
    target_calories: int
    meals: List[Meal]
    filters_applied: Optional[dict] = {}
    notes: Optional[str] = None
