# FastAPI backend for Ayurvedic Diet Management (prototype)

This is a small FastAPI-based prototype that implements user profiles, exercise logs, and a simple diet engine to generate diet plans.

Quick start (requires Python 3.10+):

```powershell
cd backend_python
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn main:app --reload --port 4000
```

API endpoints:
- GET / -> health
- POST /profiles -> create/update a user profile
- POST /profiles/{user_id}/exercise -> log exercise
- POST /profiles/{user_id}/diet-plans -> generate a diet plan (uses in-memory engine)
- GET /profiles/{user_id}/diet-plans -> list generated plans

Notes:
- This is intentionally simple and uses in-memory storage for prototyping.
- Intended as a drop-in replacement for the Node backend; adjust CORS or ports as needed.
