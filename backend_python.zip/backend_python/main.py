from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from typing import Dict
from .models import UserProfile, ExerciseLog, DietPlan
from .diet_engine import generate_plan

app = FastAPI(title="Ayurvedic Diet Engine (FastAPI)")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# In-memory stores
profiles: Dict[str, UserProfile] = {}
exercise_logs: Dict[str, list] = {}
plans_store: Dict[str, list] = {}

@app.get('/')
def health():
    return {"status": "ok"}

@app.post('/profiles', response_model=UserProfile)
def create_profile(profile: UserProfile):
    profiles[profile.id] = profile
    return profile

@app.post('/profiles/{user_id}/exercise', response_model=ExerciseLog)
def log_exercise(user_id: str, log: ExerciseLog):
    if user_id not in profiles:
        raise HTTPException(status_code=404, detail='Profile not found')
    exercise_logs.setdefault(user_id, []).append(log)
    return log

@app.post('/profiles/{user_id}/diet-plans', response_model=DietPlan)
def generate_diet_plan(user_id: str):
    if user_id not in profiles:
        raise HTTPException(status_code=404, detail='Profile not found')
    profile = profiles[user_id]
    plan = generate_plan(profile)
    plans_store.setdefault(user_id, []).append(plan)
    return plan

@app.get('/profiles/{user_id}/diet-plans')
def list_plans(user_id: str):
    return plans_store.get(user_id, [])
