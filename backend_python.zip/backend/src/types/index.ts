export interface Diet {
    id: number;
    patientId: number;
    meals: string[];
    nutritionalSummary: string;
}

export interface Patient {
    id: number;
    name: string;
    age: number;
    gender: string;
    medicalHistory: string[];
}

export interface Recipe {
    id: number;
    name: string;
    ingredients: string[];
    instructions: string;
    nutritionalInfo: string;
}