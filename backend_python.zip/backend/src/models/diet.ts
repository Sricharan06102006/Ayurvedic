export interface Diet {
    id: string;
    patientId: string;
    meals: string[];
    // Use a flexible type for the summary so services can add structured data
    nutritionalSummary: Record<string, unknown> | string;
}