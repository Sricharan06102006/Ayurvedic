import { Request, Response } from 'express';
import { DietService } from '../services/dietService';

const dietService = new DietService();

export async function createDiet(req: Request, res: Response) {
    try {
        const dietData = req.body;
        const newDiet = dietService.createDiet(dietData);
        res.status(201).json(newDiet);
    } catch (error: any) {
        res.status(500).json({ message: error?.message ?? 'Internal server error' });
    }
}

export async function getDietCharts(_req: Request, res: Response) {
    // For now return all diets stored in the in-memory service
    const all = dietService.getAll();
    res.json(all);
}

export async function getDiet(req: Request, res: Response) {
    try {
        const dietId = req.params.id;
        const diet = dietService.getDiet(dietId);
        if (diet) return res.status(200).json(diet);
        return res.status(404).json({ message: 'Diet not found' });
    } catch (error: any) {
        res.status(500).json({ message: error?.message ?? 'Internal server error' });
    }
}

export async function updateDiet(req: Request, res: Response) {
    try {
        const dietId = req.params.id;
        const dietData = req.body;
        const updated = dietService.updateDiet(dietId, dietData);
        if (updated) return res.status(200).json(updated);
        return res.status(404).json({ message: 'Diet not found' });
    } catch (error: any) {
        res.status(500).json({ message: error?.message ?? 'Internal server error' });
    }
}

export async function deleteDiet(req: Request, res: Response) {
    try {
        const dietId = req.params.id;
        const deleted = dietService.deleteDiet(dietId);
        if (deleted) return res.status(204).send();
        return res.status(404).json({ message: 'Diet not found' });
    } catch (error: any) {
        res.status(500).json({ message: error?.message ?? 'Internal server error' });
    }
}