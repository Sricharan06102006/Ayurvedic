import { Diet } from '../models/diet';
// Simple id generator to avoid external dependency
function genId(): string {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
}

export class DietService {
    private diets: Diet[] = [];

    // Create a new diet and return it
    public createDiet(dietData: Partial<Diet>): Diet {
            const diet: Diet = {
                id: dietData.id ?? genId(),
            patientId: dietData.patientId ?? '',
            meals: dietData.meals ?? [],
            nutritionalSummary: dietData.nutritionalSummary ?? {}
        };
        this.diets.push(diet);
        return diet;
    }

    // Return all diets
    public getAll(): Diet[] {
        return this.diets;
    }

    // Get a diet by id
    public getDiet(id: string): Diet | undefined {
        return this.diets.find(d => d.id === id || d.patientId === id);
    }

    // Update a diet by id and return the updated diet or null
    public updateDiet(id: string, updatedData: Partial<Diet>): Diet | null {
        const index = this.diets.findIndex(d => d.id === id || d.patientId === id);
        if (index === -1) return null;
        const existing = this.diets[index];
        const updated: Diet = {
            ...existing,
            ...updatedData,
            id: existing.id // keep original id
        };
        this.diets[index] = updated;
        return updated;
    }

    // Delete a diet by id
    public deleteDiet(id: string): boolean {
        const index = this.diets.findIndex(d => d.id === id || d.patientId === id);
        if (index === -1) return false;
        this.diets.splice(index, 1);
        return true;
    }

    // Placeholder helpers
    public generateDietPlan(patientId: string): Diet {
            const dietPlan: Diet = {
                id: genId(),
            patientId,
            meals: [],
            nutritionalSummary: {}
        };
        return dietPlan;
    }

    public analyzeRecipe(recipe: any) {
        return { nutritionalInfo: {} };
    }
}