import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import dietRoutes from './routes/dietRoutes';

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

app.use('/api/dietcharts', dietRoutes);

app.get('/', (_req, res) => res.send('Ayurvedic Diet Management API'));

const PORT = process.env.PORT ? Number(process.env.PORT) : 4000;
app.listen(PORT, () => console.log(`Backend running on port ${PORT}`));